﻿using System;

namespace tp3Consola_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            Colores Pintura = Colores.Amarillo;
            Console.WriteLine(Pintura);
        }
    }
    enum Colores {Rojo, Amarillo , Azul, Blanco};
}




