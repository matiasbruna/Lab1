﻿
using System;

namespace tp4Ejercicio9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //----D-B-C----//
            int var1 = 1;
            int var2 = 2;

            var1++;
            var2++;

            Console.WriteLine($"La variable 1: {var1} ; La varible 2: {var2}");

            //----D-E-F----//

            int var3 = 3;

            var3--;

            Console.WriteLine ($"La varible 3: {var3}");
        }
                
    }
}