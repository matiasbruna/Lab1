﻿
string nombreCliente, apellidoCliente ;
Console.WriteLine("Ingrese el Nombre del Cliente:");
nombreCliente = Console.ReadLine();

Console.WriteLine("Ingrese el Apellido del Cliente:");
apellidoCliente= Console.ReadLine();

Console.WriteLine($"{nombreCliente} {apellidoCliente}");

