﻿//--A--//

string var1 = "Matias";
string var2 = "Bruna";

Console.WriteLine($"Muestro variables: {var1} {var2}");

//--B--//

byte var3 = 0;      ///las variables byte son unicamente de de num enteros sin signo y de 0 a 255.
byte var4 = 0;

Console.WriteLine($"muestro las variables: {var3} {var4}");

//--C--//

byte var5 = 0;      //El 300 no esta dentro del rango del tipo de variable.
byte var6 = 150;      //las variables byte son unicamente de de num enteros sin signo y de 0 a 255.

Console.WriteLine($"muestro las variables: {var5} {var6}");

//--D--//

short var7 = -10;      /// variables con signo de numeros enteros hasta 16 bits.
short var8 = -100;

Console.WriteLine($"muestro las variables: {var7} {var8}");

//--E--//

short var9 = 40;      ///las variables bytes son unicamente de de num enteros sin signo y de 0 a 255.
short var10 = 600;

Console.WriteLine($"muestro las variables: {var9} {var10}");

//--F--//

int var11 = -11;
int var12 = -12;

Console.WriteLine($"Muestro variables: {var11} {var12}");

//--G--//

int var13 = 13;
int var14 = 14;

Console.WriteLine($"Muestro variables: {var13} {var14}");

//--H--//

sbyte var15 = -15;  //sbyte: variables de 8 bytes tipo entero y el rango es de -128 a 127.
sbyte var16 = -16;

Console.WriteLine($"Muestro variables: {var15} {var16}");

//--I--//

byte var17 = 17;  
byte var18 = 18;

Console.WriteLine($"Muestro variables: {var17} {var18}");

//--J--//

float var19 = 17.6f;  //variables de  tipo entero y el rango es de -128 a 127.
float var20 = 18.5f;

Console.WriteLine($"Muestro variables: {var19} {var20}");

//--K--//

double var21 = 19.6d;  //double: variables de 8 bytes tipo Reales.
double var22 = 20.5d;

Console.WriteLine($"Muestro variables: {var21} {var22}");

//--L--//

decimal  var23 = 23.662541m;  //Decimal: variables de 16 bytes, permite de 28-29 cifras de precicion.
decimal var24 = -24.554954m;

Console.WriteLine($"Muestro variables: {var23} {var24}");

//--M--//

bool  var25 = true;  //bool: variables de tipo booleano, verdadero o falso.
bool  var26 = false;

Console.WriteLine($"Muestro variables: {var25} {var26}");




